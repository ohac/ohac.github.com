//----------------------------------------------------------------------
//	�i���o�[�v���C�X
//
//	Copyright(C) 1996 Hirofumi Fujiwara 
//	�{�v���O�����́A�������܂߁A���̏��p���p�͋֎~���܂��B
//----------------------------------------------------------------------

import java.awt.*;
import java.applet.*;
import java.lang.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.awt.event.*;
import javax.swing.*;

public class NumberPlace extends Applet {

	/**
	 *
	 */
	public static void main(String[] args) {
		final JFrame frame = new JFrame("�i���o�[�v���C�X");
		NumberPlace dlg = new NumberPlace();
		frame.getContentPane().add(dlg);

		// �I������
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		dlg.setAppMode(true);
		dlg.frame = frame;
		dlg.init();
//		frame.pack();
		frame.setSize(500, 300);
		frame.show();
	}

	public void setAppMode(boolean mode) {
		appMode = mode;
	}

	public JFrame frame = null;
	private boolean appMode = false;

	final static  int  CTRLPANEL_Y =   5;
	final static  int  CTRLPANEL_H =  45;

	final static  int  SIZE = 9;

	int	bd_offx, bd_offy;
	Dimension  app_size;		// �A�v���b�g�̃T�C�Y
	int	   unit = 0;
	int	fontsize;
	int	buttonfontsize;

	boolean	curChanged = false;
	boolean	valChanged = false;
	int	curX = -1;
	int	curY = -1;
	int	oldX = -1;
	int	oldY = -1;
	Font	boxfont = null;

	Panel	controlPanel;
	JPanel buttonPanel;

	public	History	history = new History( this );

	public int probTable[][]  = new int[SIZE][SIZE];
	public int ansTable[][]   = new int[SIZE][SIZE];
	public int guessTable[][] = new int[SIZE][SIZE];
	public boolean redTable[][] = new boolean[SIZE][SIZE];
	public NumberButton buttons[] = new NumberButton[SIZE+1];
	int	fillcount[] = new int[SIZE+1];

	public void init() {
		String filename = null;
		if (appMode == false) {
			filename = getParameter("target");
		}
		app_size = this.size();	
		unit = (int)(app_size.width*0.92)/SIZE;

		String str = null;/*getParameter("unitsize");*/
		if (str == null) {
			str = "16";/*"33";*/
		}
		if( str != null ) {
			try {
				unit = (Integer.valueOf(str)).intValue();
			} catch( NoSuchElementException e ) {}
		}
		fontsize = (unit*16)/20;
		buttonfontsize = (unit*15)/20;

		setLayout( new BorderLayout() );

		setBackground( Color.white );

		//bd_offx = ( app_size.width - unit * SIZE ) / 2;
		bd_offx = 32;
System.err.println("app_size = " + app_size.width);
System.err.println("bd_offx = " + bd_offx);
		bd_offy = CTRLPANEL_H + 15;

		controlPanel = new Panel();
		controlPanel.setLayout(new FlowLayout());
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());

		Button btn = new ControlButton( this, "File", "  File  " );
		btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ev) {
						loadData(null);
					}
				});
		controlPanel.add(btn);
		controlPanel.add( new ControlButton( this, "Back", "  Back  " ) );
		controlPanel.add( new ControlButton( this, " ", "               " ) );
		controlPanel.add( new ControlButton( this, "Replay", " Replay " ) );
		controlPanel.add( new ControlButton( this, "Check", "  Check  " ) );

		Panel pd = new Panel();
		pd.setLayout( new BorderLayout() );		
		add( "South", pd );

		for( int i=1; i<=SIZE; ++i ) {
			NumberButton nb = new NumberButton( this, i, buttonfontsize );
			buttonPanel.add( nb );
			buttons[i] = nb;
		}
		add( "North", controlPanel );
		controlPanel.reshape( 0, CTRLPANEL_Y, app_size.width, CTRLPANEL_H );

		pd.add( "Center", buttonPanel );
		buttonPanel.reshape( 0, app_size.height-22-50+5, app_size.width, 50 );

		Label  copyright = new Label("Number Place V0.3" + "  " + 
						"Copyright(C)1996,2000 Hirofumi Fujiwara.",
					Label.CENTER );
		pd.add( "South", copyright );
		copyright.reshape( 0, app_size.height-22, app_size.width, 18 );

		loadData( filename );
	}

	//	���A�𓚂̓ǂݍ���
	void loadData( String filename ) {
		if (filename == null) {
			JFileChooser filedlg = new JFileChooser();
			filedlg.setCurrentDirectory(new File("."));
			int returnVal = filedlg.showOpenDialog(frame);
			if (returnVal != JFileChooser.APPROVE_OPTION) return;
			filename = filedlg.getSelectedFile().getPath();
		}
		URL		url;
		DataInputStream file;
		try {



			//!!!!!!!!!!!!!!
			/*
			url = new URL( getDocumentBase(), filename );
			file = new DataInputStream( url.openStream() );
			*/
			file = new DataInputStream(new FileInputStream(filename));
			//!!!!!!!!!!!!!!



		}
		/*
		catch( MalformedURLException e ) {
			showStatus( "file name error : " + filename );
			return;
		}
		*/
		catch( IOException e ) {
e.printStackTrace();
			showStatus( "file open error : " + filename );
			return;
		}

		String line;

		try {
			boolean	isproblem = false;
			boolean	isanswer  = false;
			int x, y=0, v;

		    nextline:
			for(;;) {
				line=file.readLine();
				if( line == null )
					break;
				if( '#' == line.charAt(0) )
					continue;
				StringTokenizer st = new StringTokenizer(line);
				try {
					for( x=0; ; ++x ) {
						String tk = st.nextToken();
						if( tk.equals("problem") ) {
							isproblem = true;
							y = 0;
							continue nextline;
						}
						if( tk.equals("answer") ) {
							isproblem = false;
							isanswer  = true;
							y = 0;
							continue nextline;
						}
						if( tk.equals("end") ) {
							break nextline;
						}

						if( tk.equals("-") ) {
System.err.println("-");
							v = 0;
						}
						else {
							v = (Integer.valueOf(tk)).intValue();
System.err.println("val = " + v + ", tk = " + tk);
						}

						if( isproblem )
							probTable[x][y] = v;
						if( isanswer )
							ansTable[x][y] = v;
					}
				} catch( NoSuchElementException e ) {}
				++y;
			}
		}
		catch( IOException e ) {
e.printStackTrace();
		}
		initFillCount();
	}

	void initFillCount() {
		for( int i=0; i<fillcount.length; ++i )
			fillcount[i] = 0;
		for( int i=0; i<SIZE; ++i )
			for( int j=0; j<SIZE; ++j ) {
				int v = probTable[i][j];
				if( v != 0 )
					++fillcount[v];
			}
		for( int i=1; i<fillcount.length; ++i )
			if( fillcount[i] == SIZE )
				buttons[i].hide();
			else
				buttons[i].show();
	}

	// (x,y) �� v ��u���i�u���Ă���j�̂͂n�j��
	boolean isOk( int x, int y, int v ) {
		int	i, j;

		// ������������
		for( i=0; i<SIZE; ++i ) {
			if( i == x )
				continue;
			if( probTable[i][y]==v || guessTable[i][y]==v )
				return	false;
		}

		// ��������
		for( i=0; i<SIZE; ++i ) {
			if( i == y )
				continue;
			if( probTable[x][i]==v || guessTable[x][i]==v )
				return	false;
		}

		// ���g����
		int	bx = (x / 3) * 3;
		int	by = (y / 3) * 3;

		for( i=bx; i<bx+3; ++i ) {
			for( j=by; j<by+3; ++j ) {
				if( i==x && j==y )
					continue;
				if( probTable[i][j]==v || guessTable[i][j]==v )
					return	false;
			}
		}
		return	true;
	}

	void buttonEnabling( int x, int y ) {
		int i, j, v;
		boolean	isused[] = new boolean[10];

		for( i=0; i<isused.length; ++i )
			isused[i] = false;

		// ��������
		for( i=0; i<SIZE; ++i ) {
			if( i == x )
				continue;
			v = probTable[i][y];
			if( v == 0 )
				v = guessTable[i][y];
			if( v > 0 )
				isused[v] = true;
		}

		// ��������
		for( i=0; i<SIZE; ++i ) {
			if( i == y )
				continue;
			v = probTable[x][i];
			if( v == 0 )
				v = guessTable[x][i];
			if( v > 0 )
				isused[v] = true;
		}

		// ���g����
		int	bx = (x / 3) * 3;
		int	by = (y / 3) * 3;

		for( i=bx; i<bx+3; ++i ) {
			for( j=by; j<by+3; ++j ) {
				if( i==x && j==y )
					continue;
				v = probTable[i][j];
				if( v == 0 )
					v = guessTable[i][j];
				if( v > 0 )
					isused[v] = true;
			}
		}
	}

	int toXPos( int i ) {
		return bd_offx + i * unit + (i/3-1)*3 + 1;
	}
	int toYPos( int i ) {
		return bd_offy + i * unit + (i/3-1)*3 + 1;
	}

	boolean isInside() {
		return  isInside( curX, curY );
	}

	boolean isInside( int i, int j ) {
		if( i<0 || i>=SIZE )
			return false;
		if( j<0 || j>=SIZE )
			return false;
		return	true;
	}

	void drawChecked( Graphics g, int x, int y ) {
		g.setColor( Color.black );
		g.drawRect( toXPos(x)+2, toYPos(y)+2, unit-6, unit-6 );
	}

	void drawNumber( Graphics g, Color c, int x, int y ) {
		drawNumber( g, c, x, y, guessTable[x][y] );
	}

	void drawNumber( Graphics g, Color c, int x, int y, int v ) {
		if( boxfont == null ) {
			boxfont = new java.awt.Font( "Helvetica", 0, fontsize );
		}

		if( v == 0 )
			return;

		g.setColor( c );
		g.setFont( boxfont );
		String s = String.valueOf(v);
		FontMetrics fm = g.getFontMetrics();
		int	sWidth = fm.stringWidth(s);
		int	sHeight = fm.getHeight();
		int	sAscent = fm. getAscent();
		g.drawString( s, toXPos(x)+(unit-sWidth)/2, toYPos(y)+(unit+sAscent)/2-2 );
	}

	public void setValue( int i, boolean ispush ) {
		if( ! isInside( curX, curY ) )
			return;
		int ov = guessTable[curX][curY];
		if( ov > 0 ) {
			if( fillcount[ov] == SIZE )
				buttons[ov].show();
			--fillcount[ov];
		}

		if( i > 0 ) {
			++fillcount[i];
			if( fillcount[i] == SIZE )
				buttons[i].hide();
		}

		guessTable[curX][curY] = i;
		if( ispush ) {
			history.push( curX, curY, ov, i );
		}
		valChanged = true;
		repaint();
	}

	public void replay() {
		history.clean();
		initFillCount();

		curX = curY = -1;

		for( int i=0; i<SIZE; ++i ) {
			for( int j=0; j<SIZE; ++j ) {
				guessTable[i][j] = probTable[i][j];
			}
		}
		repaint();
	}

	public void check() {
		int	red = 0;
		for( int i=0; i<SIZE; ++i ) {
			for( int j=0; j<SIZE; ++j ) {
				redTable[i][j] = false;
				if( probTable[i][j] != 0 )
					continue;
				if( guessTable[i][j] == 0 ) {
					redTable[i][j] = true;
					++red;
					continue;
				}
				if( ! isOk( i, j, guessTable[i][j] ) ) {
					redTable[i][j] = true;
					++red;
				}
			}
		}

		repaint();

		String	message;
		Color   col;
		if( red!=0 ) {
			message = "You are Mistaken!";
			col = Color.red;
		} else {
			message = "Congratulations!";
			col = Color.white;
		}

		InformationDialog diag = new InformationDialog( 
			this, col, "NumberPlace", message );
		
		diag.popup();
	}

	public void paint( Graphics g ) {
		g.setColor( Color.black );
		g.fillRect( bd_offx-6, bd_offy-6, unit*SIZE+13, unit*SIZE+13 );

		for( int i=0; i<SIZE; ++i ) {
			for( int j=0; j<SIZE; ++j ) {
				Color c = (i==curX && j==curY) ? Color.cyan : Color.white;
				g.setColor( c );
				g.fillRect( toXPos(i), toYPos(j), unit-1, unit-1 );
				int v;
				v = probTable[i][j];
				if( v != 0 ) {
					drawNumber( g, Color.black, i, j, v );
				} else {
					v = guessTable[i][j];
					c = redTable[i][j] ? Color.red : Color.blue;
					drawNumber( g, c, i, j, v );
				}
			}
		}
	}

	public void update( Graphics g ) {
		if( curChanged || valChanged ) {
			if( curChanged && isInside( oldX, oldY ) ) {
				g.setColor( Color.white );
				g.fillRect( toXPos(oldX), toYPos(oldY), unit-1, unit-1 );
				drawNumber( g, Color.blue, oldX, oldY );
			}
			if( isInside() ) {
				g.setColor( Color.cyan );
				g.fillRect( toXPos(curX), toYPos(curY), unit-1, unit-1 );
				drawNumber( g, Color.blue, curX, curY );
			}
			valChanged = curChanged = false;
			return;
		}

		paint( g );
	}

	public boolean mouseDown( Event evt, int x, int y ) {
		int cx = x - (bd_offx-4);
		int cy = y - (bd_offy-4);
		if( cx<0 || cy<0 )
			return true;
		cx /= unit+1;
		cy /= unit+1;
		if( cx<0 || SIZE<=cx || cy<0 || SIZE<=cy )
			return true;

		if( probTable[cx][cy] != 0 )
		return true;

		changePos( cx, cy );

		return true;
	}

	public void changePos( int cx, int cy ) {
		oldX = curX;  curX = cx;
		oldY = curY;  curY = cy;
		curChanged = true;
		repaint();
	}

	public boolean action( Event evt, Object arg ) {
		return	true;
	}
}

//--------------------------------------------------------------------------------
//	����{�^���N���X
//--------------------------------------------------------------------------------
class  ControlButton extends Button {
	NumberPlace	np;
	String		name;

	// �\�z�q
	ControlButton( NumberPlace p, String str, String label ) {
		super();
		np = p;
		name = str;
		setLabel( label );
		Font	bf = new java.awt.Font( "Helvetica", 0, 20 );
		setFont( bf );
	}

	public boolean action( Event evt, Object obj ) {
		if( name.equals(" ") ) {
			np.setValue( 0, true );
			return true;
		}
		if( name.equals("Back") ) {
			np.history.pop();
			return true;
		}
		if( name.equals("Replay") ) {
			np.replay();
			return true;
		}
		if( name.equals("Check") ) {
			np.check();
			return true;
		}
		return true;
	}
}

//--------------------------------------------------------------------------------
//	�����{�^���N���X
//--------------------------------------------------------------------------------
class  NumberButton extends Button {
	NumberPlace	np;
	int	id;

	// �\�z�q
	NumberButton( NumberPlace p, int i, int fontsize ) {
		super();
		np = p;
		id = i;
		setLabel( ""+i );
		Font	bf = new java.awt.Font( "Helvetica", 0, fontsize );
		setFont( bf );
	}

	public boolean action( Event evt, Object obj ) {
		np.setValue( id, true );
        	return true;
	}
}

//--------------------------------------------------------------------------------
//	�q�X�g���[
//--------------------------------------------------------------------------------
class  History {
	NumberPlace	np;
	int	history[][] = new int[1000][4];
	int	current;
	int	last;

	History( NumberPlace p ) {
		np = p;
		clean();
	}

	public	void clean() {
		current = last = 0;
	}

	public	void push( int x, int y, int o, int v ) {
		if(current >= history.length )
			return;

		history[current][0] = x;
		history[current][1] = y;
		history[current][2] = o;
		history[current][3] = v;
		++current;
		if( last < current )
			last = current;
	}

	public void pop() {
		if( current <= 0 )
			return;

		--current;
		int  x = history[current][0];
		int  y = history[current][1];
		int  o = history[current][2];
		int  v = history[current][3];

		np.changePos( x, y );
		np.setValue( o, false );
	}
}

//--------------------------------------------------------------------------------
//	���_�C�A���O
//--------------------------------------------------------------------------------
class	InformationDialog extends Frame {
	Applet		app;
	protected	Button	button;

	public InformationDialog( Applet a, Color col, String title, String message )	{
		app = a;		

		setTitle( title );
		setFont(new Font("TimesRoman", Font.BOLD, 32));

		this.setLayout( new BorderLayout( 30, 30 ) );
		setBackground( col );
	
		Label	label = new Label( message );
		add( "Center", label );

		button = new Button( "OK" );
		Panel p = new Panel();
		p.setLayout( new FlowLayout( FlowLayout.CENTER, 30, 30 ) );
		p.add( button );
		add( "South", p );

		pack();
	}

	public void popup() {
		/*
		Frame	frame = (Frame)app.getParent();
		Point	    pos  = frame.location();
		Dimension   size = frame.size();
		Dimension   mysize = size();

		move( pos.x+(size.width-mysize.width)/2, 
		      pos.y+(size.height-mysize.height)/2 );
		      */
		show();
	}

	public boolean action( Event e, Object obj ) {
		if( e.target == button ) {
			hide();
			dispose();
			return	true;
		} else
			return	false;
	}

	public	boolean	getFocus( Event e, Object obj ) {
		button.requestFocus();
		return	true;
	}
}

//--------------------------------------------------------------------------------
//		end of "NumberPlace.java",  by Hirofumi Fujiwara
//--------------------------------------------------------------------------------

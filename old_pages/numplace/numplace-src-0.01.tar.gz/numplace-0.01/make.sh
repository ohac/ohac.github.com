#!/bin/bash
rm -fr classes
mkdir classes
javac -encoding SJIS -nowarn -deprecation -d classes *.java
( cd classes ; jar cvmf ../numplace.mf ../numplace.jar *.class )

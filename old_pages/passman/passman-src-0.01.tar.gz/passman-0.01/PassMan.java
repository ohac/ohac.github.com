import java.util.zip.*;

/**
 *
 */
public class PassMan {

	/**
	 * �Í������s���B
	 */
	public static String encrypt(String text, String pass) {
		CRC32 crc = new CRC32();
		String temppass = createTempPass();
		StringBuffer strbuf = new StringBuffer();
		strbuf.append(temppass);
		strbuf.append(":");
		temppass = temppass + pass;
		byte[] passarray = temppass.getBytes();
		crc.update(passarray);
		long key = crc.getValue();
		byte[] textarray = text.getBytes();
		int textlen = textarray.length;
		// encrypt
		for (int j = 0; j < textlen; j++) {
			textarray[j] ^= (byte)(key >> (24 - (j % 4) * 8));
		}
		// base64
		for (int j = 0;; j++) {
			int val = 0, level = 2;
			if (j * 3 >= textlen) break;
			val |= ((textarray[j * 3] & 0x0ff) << 24);
			if ((j * 3 + 1) < textlen) {
				val |= ((textarray[j * 3 + 1] & 0x0ff) << 16);
				level = 3;
			}
			if ((j * 3 + 2) < textlen) {
				val |= ((textarray[j * 3 + 2] & 0x0ff) << 8);
				level = 4;
			}
			for (int k = 0; k < level; k++) {
				int pos = (int)((val >> (26 - (k * 6))) & 0x3f);
				strbuf.append(BASE64_TABLE.charAt(pos));
			}
		}
		return new String(strbuf);
	}

	/**
	 * ���������s���B
	 */
	public static String decrypt(String text, String pass) {
		int pos = text.indexOf(":");
		if (pos <= 0) return null;
		String temppass = text.substring(0, pos) + pass;
		String crypt = text.substring(pos + 1);
		byte[] passarray = temppass.getBytes();
		CRC32 crc = new CRC32();
		crc.update(passarray);
		long key = crc.getValue();
		byte[] cryarray = crypt.getBytes();
		int crylen = cryarray.length;
		int origlen = (crylen / 4) * 3;
		if ((crylen % 4) == 2) {
			origlen++;
System.out.println("origlen = " + origlen);
		}
		if ((crylen % 4) == 3) origlen += 2;
		byte[] arraybuf = new byte [origlen];
		int arraybufpos = 0;
		// base64
		for (int j = 0;; j++) {
			if (j * 4 >= crylen) break;
			int val = 0, level = 1;
			pos = BASE64_TABLE.indexOf(cryarray[j * 4]);
			if (pos < 0) return null;
			val |= pos << 26;
			if ((j * 4 + 1) < crylen) {
				pos = BASE64_TABLE.indexOf(cryarray[j * 4 + 1]);
				if (pos < 0) return null;
				val |= pos << 20;
				level = 1;
			}
			if ((j * 4 + 2) < crylen) {
				pos = BASE64_TABLE.indexOf(cryarray[j * 4 + 2]);
				if (pos < 0) return null;
				val |= pos << 14;
				level = 2;
			}
			if ((j * 4 + 3) < crylen) {
				pos = BASE64_TABLE.indexOf(cryarray[j * 4 + 3]);
				if (pos < 0) return null;
				val |= pos << 8;
				level = 3;
			}
			for (int k = 0; k < level; k++) {
				arraybuf[arraybufpos++] = (byte)(val >> (24 - k * 8));
			}
		}
		// decrypt
		for (int j = 0; j < origlen; j++) {
			arraybuf[j] ^= (byte)(key >> (24 - (j % 4) * 8));
		}
		return new String(arraybuf);
	}

	/**
	 * ����ς��p�X���[�h�𓾂܂��B
	 */
	public static String createTempPass() {
		StringBuffer strbuf = new StringBuffer();
		int len = BASE64_TABLE.length();
		for (int j = 0; j < 8; j++) {
			double random = Math.random();
			int pos = (int)(random * len);
			strbuf.append(BASE64_TABLE.charAt(pos));
		}
		return new String(strbuf);
	}

	/**
	 *
	 */
	private static final String BASE64_TABLE =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "abcdefghijklmnopqrstuvwxyz"
 			+ "0123456789+/";

	/**
	 *
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("usage: option masterpass string");
			System.out.println("option: -e encrypt");
			System.out.println("        -d decrypt");
		}
		else if (args[0].equals("-e")) {
			String masterpass = args[1];
			String crypttext = encrypt(args[2], masterpass);
			System.out.println("crypttext = " + crypttext);
		}
		else if (args[0].equals("-d")) {
			String masterpass = args[1];
			String origtext = decrypt(args[2], masterpass);
			System.out.println("origtext = " + origtext);
		}
	}

}

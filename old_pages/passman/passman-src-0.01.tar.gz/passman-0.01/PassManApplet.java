import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 */
public class PassManApplet extends JApplet {

	/**
	 *
	 */
	public void init() {
		Container base = getContentPane();
		// ��
		JPanel pnl = new JPanel();
		base.add(pnl, BorderLayout.NORTH);
		pnl.add(new JLabel("�}�X�^�[�p�X���[�h"));
		pnl.add(passField);
		passField.setPreferredSize(new Dimension(120, 24));

		// ����
		pnl = new JPanel();
		base.add(pnl, BorderLayout.CENTER);

		JPanel pnl3 = new JPanel(new GridLayout(3, 1));
		pnl.add(pnl3);
		JPanel pnl2 = new JPanel();
		pnl3.add(pnl2);
		pnl2.add(new JLabel("����"));

		pnl2 = new JPanel();
		pnl3.add(pnl2);
		textField.setPreferredSize(new Dimension(120, 24));
		pnl2.add(textField);

		pnl2 = new JPanel();
		pnl3.add(pnl2);
		JButton btn = new JButton("�Í���");
		pnl2.add(btn);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				encrypt();
			}
		});

		pnl3 = new JPanel(new GridLayout(3, 1));
		pnl.add(pnl3);
		pnl2 = new JPanel();
		pnl3.add(pnl2);
		pnl2.add(new JLabel("�Í���"));

		pnl2 = new JPanel();
		pnl3.add(pnl2);
		cryptField.setPreferredSize(new Dimension(120, 24));
		pnl2.add(cryptField);

		pnl2 = new JPanel();
		pnl3.add(pnl2);
		btn = new JButton("������");
		pnl2.add(btn);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				decrypt();
			}
		});

	}

	/**
	 *
	 */
	public static void main(String[] args) {
		final JFrame frame = new JFrame("�p�X���[�h�Ǘ�");
		PassManApplet dlg = new PassManApplet();
		frame.getContentPane().add(dlg);

		// �I������
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		dlg.init();
		frame.pack();
		frame.show();
	}


	/**
	 *
	 */
	private void encrypt() {
		String masterpass = new String(passField.getPassword());
		String crypt = PassMan.encrypt(textField.getText(), masterpass);
		cryptField.setText(crypt);
	}

	/**
	 *
	 */
	private void decrypt() {
		String masterpass = new String(passField.getPassword());
		String text = PassMan.decrypt(cryptField.getText(), masterpass);
		textField.setText(text);
	}

	/**
	 *
	 */
	private JPasswordField passField = new JPasswordField();

	/**
	 *
	 */
	private JTextField cryptField = new JTextField();

	/**
	 *
	 */
	private JTextField textField = new JTextField();

}

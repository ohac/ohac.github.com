#!/bin/bash
rm -fr classes
mkdir classes
javac -encoding Shift_JIS -deprecation -d classes *.java
( cd classes ; jar cvmf ../passman.mf ../passman.jar *.class )

/**
 * DailyJobs
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
import java.util.*;
import java.io.*;
import java.text.*;

public class DailyJobs {

	/**
	 * "- 2001.12.12 memo"��"2001.12.12"�̕�������荞��
	 */
	public void parseLine(String line) {
		StringTokenizer tknr = new StringTokenizer(line);
		tknr.nextToken();
		title = tknr.nextToken();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		try {
			date = sdf.parse(title);
		}
		catch (ParseException x) {
		}
	}

	/**
	 * "@,����,9,17.5"����荞��
	 */
	public void parseExtLine(String line) {
		// "@,"���폜
		line = line.substring(2);
		// "����"(��)�̕��������o��
		int pos = line.indexOf(",");
		if (pos <= 0) return;
		String name = line.substring(0, pos);
		// "9,17.5"(��)�̕��������o��
		String params = line.substring(pos + 1);
		exts.put(name, params);
	}

	/**
	 *
	 */
	public void addJob(Job job) {
		jobs.addElement(job);
	}

	/**
	 *
	 */
	public void createDocument(BufferedWriter parentWriter, Job projects)
			throws IOException {
		if (parentWriter == null) return;
		sort(projects);
		parentWriter.write("<tr><td rowspan=\"" + (jobs.size() + 1) + "\">"
				+ title + "</td>");
		parentWriter.newLine();
		Iterator ite = jobs.iterator();
		float result = 0, expect = 0;
		boolean firstf = true;
		while (ite.hasNext()) {
			if (!firstf) {
				parentWriter.write("<tr>");
				parentWriter.newLine();
			}
			Job job = (Job)ite.next();
			// �O��܂ł̎��ю���
			float lastResultVol = job.getLastResultVolume();
			if (lastResultVol < 0) lastResultVol = 0;
			float thisExpectVol = job.getExpectVolume();
			if (thisExpectVol < 0) thisExpectVol = 0;
			String name = job.getName();
			Job projectJob = job;
			parentWriter.write("<td>" + projectJob.getTopName() + "</td>");
			parentWriter.newLine();
			String dirName = projectJob.getDirName();
			if (dirName.length() > 0) dirName = "("  + dirName + ")";
			parentWriter.write("<td>" + name + dirName + "</td>");
			parentWriter.newLine();
			parentWriter.write("<td align=\"right\">"
					+ floatToString(thisExpectVol) + "</td>");
			parentWriter.newLine();
			parentWriter.write("<td align=\"right\">"
					+ floatToString(lastResultVol) + "</td>");
			parentWriter.newLine();
			parentWriter.write("</tr>");
			parentWriter.newLine();
			firstf = false;
			result += lastResultVol;
			expect += thisExpectVol;
		}
		if (!firstf) {
			parentWriter.write("<tr>");
			parentWriter.newLine();
		}
		parentWriter.write("<td bgcolor=\"silver\">���v</td>");
		parentWriter.newLine();
		parentWriter.write("<td bgcolor=\"silver\">-</td>");
		parentWriter.newLine();
		parentWriter.write("<td bgcolor=\"silver\" align=\"right\">"
				+ floatToString(expect) + "</td>");
		parentWriter.newLine();
		parentWriter.write("<td bgcolor=\"silver\" align=\"right\">"
				+ floatToString(result) + "</td>");
		parentWriter.newLine();
		parentWriter.write("</tr>");
		parentWriter.newLine();
		parentWriter.write("</tr>");
		parentWriter.newLine();
	}

	/**
	 *
	 */
	public boolean isTargetWeek(int year, int weekOfYear) {
		if (date == null) return false;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return (cal.get(Calendar.YEAR) == year
				&& cal.get(Calendar.WEEK_OF_YEAR) == weekOfYear);
	}

	/**
	 *
	 */
	private void sort(Job projects) {
		Object[] jobAry = jobs.toArray();
		for (int j = 0; j < jobAry.length; j++) {
			Job jobitem = (Job)jobAry[j];
			if (jobitem.getId() == null) continue;
			Job job = projects.getChildJob(jobitem.getId());
			if (job != null) {
				// �\�[�g���邽�߂ɐe�W���u��o�^(�Е����̂�)
				jobitem.setParentJob(job.getParentJob());
			}
		}
		Arrays.sort(jobAry);
		jobs.removeAllElements();
		for (int j = 0; j < jobAry.length; j++) {
			jobs.add(jobAry[j]);
		}
	}

	/**
	 *
	 */
	private static String floatToString(float val) {
		int ival = (int)(val * 10 + 0.5);
		return Integer.toString(ival / 10) + "." + (ival % 10);
	}

	/**
	 *
	 */
	private String title;

	/**
	 *
	 */
	private Vector jobs = new Vector();

	/** */
	public Hashtable getExts() { return exts; }

	/**
	 * �g���̈�(�Ζ����ԓ�)
	 */
	private Hashtable exts = new Hashtable();

	/** */
	public Vector getJobs() { return jobs; }

	/** */
	public Date getDate() { return date; }

	/** */
	private Date date;

}

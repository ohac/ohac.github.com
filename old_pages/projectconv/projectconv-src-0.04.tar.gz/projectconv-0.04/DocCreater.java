/**
 * DocCreater
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

import java.io.*;
import java.util.*;

/**
 * ���{��SJIS�ł��B
 * �v���W�F�N�g���L�[�ɂ����Ǘ�
 */
public class DocCreater {

	/**
	 *
	 */
	public void addDailyJobs(DailyJobs daily) {
		Date date = daily.getDate();
		if (date == null) return;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int week = cal.get(Calendar.WEEK_OF_YEAR);
		int dayw = cal.get(Calendar.DAY_OF_WEEK);

		// �g���̈�̏���(�Ζ����ԓ�)
		Hashtable exts = daily.getExts();
		Iterator ite = exts.keySet().iterator();
		while (ite.hasNext()) {
			String key = (String)ite.next();
			String params = (String)exts.get(key);
			Vector vect = (Vector)vects.get(key);
			if (vect == null) {
				vect = new Vector();
				vects.put(key, vect);
			}
			StringTokenizer tknr = new StringTokenizer(params, ",");
			float parama = -1;
			float paramb = -1;
			try {
				parama = Float.parseFloat(tknr.nextToken());
			}
			catch (Exception x) {
			}
			try {
				paramb = Float.parseFloat(tknr.nextToken());
			}
			catch (Exception x) {
			}
			vect.addElement(new Item(year, month, day, week, dayw
					, parama, paramb));
		}

		Vector jobs = daily.getJobs();
		ite = jobs.iterator();
		while (ite.hasNext()) {
			Job job = (Job)ite.next();
			float amount = job.getLastResultVolume();
			if (amount <= 0) continue;
			if (job.getTopJob() == null) continue;
			Vector vect = (Vector)vects.get(job.getTopJob());
			if (vect == null) {
				vect = new Vector();
				vects.put(job.getTopJob(), vect);
			}
			vect.addElement(new Item(year, month, day, week, dayw, amount));
		}
	}

	/**
	 *
	 */
	public void createDocument(User user, int year
			, int weekOfYear) throws IOException {
		String fname = user.getId() + "_" + year //+ "_" + weekOfYear
				+ ".schedule";
		if (outputPath != null) fname = outputPath + File.separator + fname;
		FileWriter fileWriter = new FileWriter(fname, true);
		try {
			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
			Iterator ite = vects.keySet().iterator();
			createCalendarGuide(bufWriter, year, weekOfYear);
			while (ite.hasNext()) {
				Object obj = ite.next();
				String extName = null;
				boolean extMode = false;
				if (obj instanceof String) {
					// �g���̈�̏���(�Ζ����ԓ�)
					extName = "xx-xxxxx-xx �Ζ����Ԑ\���i�\�聄" + obj + "�j";
					extMode = true;
				}
				else {
					Job job = (Job)obj;
					extName = job.getName();
				}
				Vector vect = (Vector)vects.get(obj);
				Iterator ite2 = vect.iterator();
				int lastdw = 1;
				float lastamount = 0;
				float lastext = 0;
				while (ite2.hasNext()) {
					Item item = (Item)ite2.next();
					if (lastdw != item.dayw) {
						if (lastext > 0) {
							bufWriter.write("|  " + lastamount + "- "
									+ lastext);
							lastdw++;
							lastamount = 0;
							lastext = 0;
						}
						else if (lastamount > 0) {
							bufWriter.write((extMode ? STR2 : STR1)
									+ " " + lastamount);
							lastdw++;
							lastamount = 0;
						}
					}
					for (int j = lastdw; j < item.dayw; j++) {
						bufWriter.write(STR1 + STR3);
						lastdw++;
					}
					if (item.amount > 0) lastamount += item.amount;
					if (item.ext > 0) lastext += item.ext;
				}
				if (lastamount > 0) {
					bufWriter.write(STR1 + " " + lastamount);
				}
				for (int j = lastdw; j < 7; j++) {
					bufWriter.write((extMode ? STR2 : STR1) + STR3);
				}
				bufWriter.write("|" + user.getName() + "|" + extName);
				bufWriter.newLine();
			}
			bufWriter.flush();
		}
		finally {
			fileWriter.close();
		}
	}

	/**
	 *
	 */
	public void createCalendarGuide(BufferedWriter bufWriter, int year
			, int weekOfYear) throws IOException {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.DAY_OF_WEEK, 1);
		cal.set(Calendar.WEEK_OF_YEAR, weekOfYear);
		for (int j = 0; j < 7; j++) {
			int mon = (cal.get(Calendar.MONTH) + 1);
			int day = cal.get(Calendar.DAY_OF_MONTH);
			bufWriter.write(" " + cal.get(Calendar.YEAR) + "/"
					+ ((mon >= 10) ? "" : "0") + mon + "/"
					+ ((day >= 10) ? "" : "0") + day + " ");
			cal.add(Calendar.DAY_OF_WEEK, 1);
		}
		bufWriter.newLine();
	}

	/**
	 *
	 */
	public void setOutputPath(String path) {
		outputPath = path;
	}

	/** �L�[ ID: String, ���e :Vector ( ���e :Item ) */
	private Hashtable vects = new Hashtable();

	private String outputPath = null;

	private final static String STR1 = "|(  . ) ";
	private final static String STR2 = "|   . - ";
	private final static String STR3 = "  . ";

}

class Item {

	public Item(int y, int m, int d, int w, int dw, float a, float e) {
		year = y;
		month = m;
		day = d;
		week = w;
		dayw = dw;
		amount = a;
		ext = e;
	}

	public Item(int y, int m, int d, int w, int dw, float a) {
		this(y, m, d, w, dw, a, -1);
	}

	public String toString() {
		return "" + year + "/" + (month + 1) + "/" + day + ":" + amount;
	}

	/** �N(����) */
	private int year;

	/** ��(0�`11) */
	private int month;

	/** �� */
	private int day;

	/** �T */
	private int week;

	/** �j�� */
	public int dayw;

	/** ��Ǝ��� */
	public float amount;

	/** �ėp���� */
	public float ext;

}


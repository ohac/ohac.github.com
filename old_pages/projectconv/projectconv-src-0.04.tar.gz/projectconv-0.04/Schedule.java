/**
 * Schedule
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
import java.io.*;
import java.util.*;

/**
 *
 */
public class Schedule {

	/**
	 *
	 */
	public Schedule() {
		projects.setId("index");
		projects.setName("�v���W�F�N�g�ꗗ");
	}

	/**
	 *
	 */
	public boolean loadFile(String fname, String enc) throws IOException {
		boolean rv = true;
		if (enc == null) enc = "JISAutoDetect";
		projects.clearAllChildJobs();
		lines.clear();
		int stage = NONE;
		FileInputStream fileIn = new FileInputStream(fname);
		InputStreamReader inReader = new InputStreamReader(fileIn, enc);
		try {
			BufferedReader bufReader = new BufferedReader(inReader);
			Job job = null;
			Job lastJob = null;
			User user = null;
			DailyJobs daily = null;
			// Job ID�̏d�����m�F���邽�߂̃e�[�u��
			Hashtable jobIdMemo = new Hashtable();
			for (int lno = 1;; lno++) {
				String line = bufReader.readLine();
				if (line == null) break;
				if (job == null) {
					// stage��USER�̂Ƃ��̓V���{���b�N�����N�Ƃ���
					job = new Job(!(stage == PROJECTS));
				}
				try {
					if (stage == NONE) throw new RuntimeException();
					if (job.parseLine(line, lno) == false) rv = false;
					lines.addElement(job);
					if (stage == PROJECTS) {
						if (jobIdMemo.get(job.getId()) != null) {
							// Job ID���d�����Ă���̂ŃG���[
							logger.addString("Line: " + lno + ", Error: "
									+ "Conflict ID = " + job.getId());
							rv = false;
						}
						jobIdMemo.put(job.getId(), job);
						addJob(job, lastJob);
						// �e�S���҂̓�����A���т����o���Ĕ��f������
						if (job.getId() != null) {
							Job tempjob = (Job)lastJobs.get(job.getId());
							if (tempjob != null) {
								// ���ю���
								job.setResultVolume(tempjob.getResultVolume());
								job.setCheck(tempjob.getCheck());
								// ���ю��Ԃ����L���ŁA�`�F�b�N���Ă���ꍇ��
								// ���ς���H�������̂܂܎��тƂ���
								if (job.getCheck() && job.getResultVolume()
										< 0) {
									job.setResultVolume(job.getExpectVolume());
								}
							}
						}
					}
					else if (stage == USER) {
						job.setDailyMode(true);
						daily.addJob(job);
						// �ŏI���̎��т��L�^
						if (job.getId() != null) {
							Job tempjob = (Job)lastJobs.get(job.getId());
							// ���������𐔓��ɂ킽���č�Ƃ����ꍇ
							// ��Ǝ��Ԃ̍��������
							if (tempjob != null) {
								job.setResultVolume(job.getResultVolume()
										+ tempjob.getResultVolume());
							}
							lastJobs.put(job.getId(), job);
						}
					}
					lastJob = job;
					// ���񃂁[�h�ł͖���new���邽��null��ݒ�
					job = null;
				}
				catch (Exception x) {
					// �����̍s
					lines.addElement(line);
					// ����R�}���h�s�̂Ƃ�
					if (line.startsWith("#")) {
						// �v���W�F�N�g
						if (line.startsWith("#projects")) {
							stage = PROJECTS;
						}
						// ���[�U�[
						else if (line.startsWith("#user ")) {
							stage = USER;
							user = new User();
							user.parseLine(line);
							users.addUser(user);
						}
						else {
							stage = NONE;
						}
					}
					// ����
					else if (stage == USER && line.startsWith("- ")) {
						daily = new DailyJobs();
						daily.parseLine(line);
						user.addDailyJobs(daily);
					}
					// �g���s
					else if (stage == USER && line.startsWith("@,")) {
						daily.parseExtLine(line);
					}
				}
			}
		}
		finally {
			fileIn.close();
		}
		return rv;
	}

	/**
	 *
	 */
	public void saveFile(String fname, String enc) throws IOException {
		FileOutputStream fileIn = new FileOutputStream(fname);
		try {
			OutputStreamWriter outWriter = null;
			if (enc == null) {
				outWriter = new OutputStreamWriter(fileIn);
			}
			else {
				outWriter = new OutputStreamWriter(fileIn, enc);
			}
			BufferedWriter bufWriter = new BufferedWriter(outWriter);
			Iterator ite = lines.iterator();
			while (ite.hasNext()) {
				bufWriter.write(ite.next().toString());
				bufWriter.newLine();
			}
			bufWriter.flush();
		}
		finally {
			fileIn.close();
		}
	}

	private void addJob(Job job, Job lastJob) {
		int level = job.getLevel();
		// �g�b�v���x���̏ꍇ�� projects �ɒǉ�����
		if (level == 0) {
			projects.addChildJob(job);
		}
		else if (lastJob != null) {
			Job tempJob = lastJob;
			while (true) {
				if (level > tempJob.getLevel()) break;
				tempJob = tempJob.getParentJob();
				if (tempJob == null) break;
			}
			if (tempJob != null) {
				// �e�̐ݒ�
				job.setParentJob(tempJob);
				// �q�̒ǉ�
				tempJob.addChildJob(job);
			}
		}
	}

	private static final int NONE = 0;

	private static final int PROJECTS = 1;

	private static final int USER = 2;

	/**
	 * lines:Vector <job:Job | line:String>
	 */
	private Vector lines = new Vector();

	/**
	 *
	 */
	private UserList users = new UserList();

	/**
	 * 
	 */
	private Job projects = new Job(false);

	/**
	 * lastJobs:Hashtable < id:String, job:Job >
	 */
	private Hashtable lastJobs = new Hashtable();

	/**
	 *
	 */
	public static boolean convert(File infile, File outfile, String enc)
			throws IOException {
		Schedule sche = new Schedule();
		boolean rv = sche.loadFile(infile.getAbsolutePath(), enc);
		sche.saveFile(outfile.getAbsolutePath(), enc);
		sche.projects.setOutputPath(outfile.getParent());
		sche.projects.createDocument();
		sche.users.setOutputPath(outfile.getParent());
		sche.users.createDocument(sche.projects);
		return rv;
	}

	/** �G���[�A�x���\���p�̃C���^�[�t�F�[�X */
	public static MessageLogger logger = new MessageLogger() {
		public void addString(String str) {
			System.out.println(str);
		}
	};

	/**
	 *
	 */
	public static boolean convert(File infile) throws IOException {
		return convert(infile, null);
	}

	/**
	 *
	 */
	public static boolean convert(File infile, String enc) throws IOException {
		boolean rv = false;
		String infname = infile.getAbsolutePath();
		File outfile = new File(infname + ".conv");
		if (convert(infile, outfile, enc)) {
			rv = true;
			// �������̓t�@�C����u��������
			File oldfile = new File(infname + ".orig");
			oldfile.delete();
			infile.renameTo(oldfile);
			outfile.renameTo(infile);
		}
		return rv;
	}

	/**
	 *
	 */
	public static void main(String[] args) {
		try {
			if (args.length == 0) {
				System.out.println(USAGE_STRING);
			}
			else if (args.length == 1) {
				convert(new File(args[0]), null);
			}
			else if (args.length == 2) {
				convert(new File(args[0]), args[1]);
			}
		}
		catch (Exception x) {
			x.printStackTrace();
		}
	}

	private static final String USAGE_STRING
			= "Usage: filename [encoding]\n"
			+ "Options:\n"
			+ "encoding = SJIS or EUCJIS or JIS\n";

}

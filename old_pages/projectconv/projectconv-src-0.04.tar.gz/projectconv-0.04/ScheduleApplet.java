/**
 * ScheduleApplet
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.util.List;
import java.util.Iterator;
import java.io.File;
import javax.swing.*;

public class ScheduleApplet extends JApplet implements DropTargetListener
		, MessageLogger {

	/**
	 *
	 */
	public ScheduleApplet() {
		// Drag&Drop�Ή�
		DropTarget dnd = new DropTarget(output, this);

		// �o�[�W�����\��
		output.append("�v���W�F�N�g�Ǘ��c�[�� Ver.0.04\n");
		output.append("Copyright (C) 2001 OHASHI Hideya\n");
		output.append("�����Ƀh���b�O�A���h�h���b�v���Ă��������B\n");

		Container cpane = getContentPane();

		// ����
		cpane.add(output, BorderLayout.CENTER);
		output.setPreferredSize(new Dimension(400, 200));

	}

	public void dragEnter(DropTargetDragEvent ev) {
	}

	public void dragExit(DropTargetEvent ev) {
	}

	public void dragOver(DropTargetDragEvent ev) {
	}

	public void drop(DropTargetDropEvent ev) {
		Transferable trns = ev.getTransferable();
		if (trns.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
			ev.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
			try {
				List list = (List)trns.getTransferData(
						DataFlavor.javaFileListFlavor);
				for (Iterator it = list.iterator(); it.hasNext(); ) {
					File file = (File)it.next();
					output.append("�ϊ��� " + file.getAbsolutePath() + "\n");
					if (Schedule.convert(file)) {
						output.append("�ϊ�����\n");
					}
					else {
						output.append("�ϊ����s\n");
					}
				}
			}
			catch (Exception x) {
				output.append("�ϊ����s " + x + "\n");
				x.printStackTrace();
			}
			ev.dropComplete(true);
		}
	}

	public void dropActionChanged(DropTargetDragEvent ev) {
	}

	public void addString(String str) {
		output.append(str + "\n");
	}

	/**
	 *
	 */
	private JTextArea output = new JTextArea();

	public static void main(String[] args) {
		final JFrame frame = new JFrame("�v���W�F�N�g�Ǘ��c�[��");
		ScheduleApplet applet = new ScheduleApplet();
		frame.getContentPane().add(applet);
		Schedule.logger = applet;

		// �I������
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		frame.pack();
		frame.show();
	}

}

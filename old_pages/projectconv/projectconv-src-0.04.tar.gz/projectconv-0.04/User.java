/**
 * User
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
import java.util.*;
import java.io.*;

/**
 *
 */
public class User {

	/**
	 *
	 */
	public String getId() {
		return id;
	}

	/**
	 *
	 */
	public String getName() {
		return name;
	}

	/**
	 *
	 */
	public void setId(String val) {
		id = val;
	}

	/**
	 *
	 */
	public void setName(String val) {
		name = val;
	}

	/**
	 * @param line "#user id,name"
	 */
	public void parseLine(String line) {
		int pos = line.indexOf(" ");
		if (pos <= 0) return;
		StringTokenizer tknr = new StringTokenizer(line.substring(pos + 1)
				, ",");
		try {
			id = tknr.nextToken();
			name = tknr.nextToken();
		}
		catch (Exception x) {
		}
		if (name == null) name = id;
	}

	/**
	 *
	 */
	public void addDailyJobs(DailyJobs daily) {
		dailyJobsTable.addElement(daily);
		Date date = daily.getDate();
		if (date == null) return;
		long time = date.getTime();
		if (minimumTime == 0) {
			minimumTime = time;
			maximumTime = time;
		}
		else {
			if (minimumTime > time) minimumTime = time;
			else if (maximumTime < time) maximumTime = time;
		}
	}

	/**
	 *
	 */
	public String getURLString() {
		return id + ".html";
	}

	private String getURLString(int year, int weekOfYear) {
		return id + "_" + year + "_" + weekOfYear + ".html";
	}

	/**
	 *
	 */
	public void createDocument(BufferedWriter parentWriter, Job projects)
			throws IOException {
		String url = getURLString();
		if (parentWriter != null) {
			parentWriter.write("<tr><td><a href=\"" + url + "\">" + name
					+ "</a></td>");
			parentWriter.newLine();
			parentWriter.write("</tr>");
			parentWriter.newLine();
		}
		String fname = url;
		if (outputPath != null) fname = outputPath + File.separator + fname;
		FileWriter fileWriter = new FileWriter(fname);
		try {
			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
			writeHeader(bufWriter);
			Iterator ite = dailyJobsTable.iterator();
			while (ite.hasNext()) {
				DailyJobs daily = (DailyJobs)ite.next();
				daily.createDocument(bufWriter, projects);
			}
			writeFooter(bufWriter);
			bufWriter.flush();
		}
		finally {
			fileWriter.close();
		}
		if (minimumTime == 0) return;
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date(minimumTime));
		int lastYear = -1;
		int lastWeek = -1;
		while (true) {
			int year = cal.get(Calendar.YEAR);
			int week = cal.get(Calendar.WEEK_OF_YEAR);
			url = getURLString(year, week);
			if (lastYear != year || lastWeek != week) {
				lastYear = year;
				lastWeek = week;
				if (parentWriter != null) {
					parentWriter.write("<tr><td><a href=\"" + url + "\">" + name
							+ " " + year + "�N/��" + week + "�T"
							+ "(" + (cal.get(Calendar.MONTH) + 1) + "��)"
							+ "</a></td>");
					parentWriter.newLine();
					parentWriter.write("</tr>");
					parentWriter.newLine();
				}
				createWeeklyDocument(projects, year, week);
			}
//			cal.add(Calendar.WEEK_OF_YEAR, 1);
			cal.add(Calendar.DAY_OF_YEAR, 1);
			if (cal.getTime().getTime() > maximumTime) break;
		}
	}

	/**
	 *
	 */
	public void createWeeklyDocument(Job projects, int year, int weekOfYear)
			throws IOException {
		String fname = getURLString(year, weekOfYear);
		if (outputPath != null) fname = outputPath + File.separator + fname;
		FileWriter fileWriter = new FileWriter(fname);
		DocCreater docCreater = new DocCreater();
		docCreater.setOutputPath(outputPath);
		try {
			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
			writeHeader(bufWriter);
			Iterator ite = dailyJobsTable.iterator();
			while (ite.hasNext()) {
				DailyJobs daily = (DailyJobs)ite.next();
				if (daily.isTargetWeek(year, weekOfYear) == false) continue;
				daily.createDocument(bufWriter, projects);
				docCreater.addDailyJobs(daily);
			}
			writeFooter(bufWriter);
			bufWriter.flush();
			docCreater.createDocument(this, year, weekOfYear);
		}
		finally {
			fileWriter.close();
		}
	}

	/**
	 *
	 */
	public void writeHeader(BufferedWriter writer) throws IOException {
		writer.write("<html><body>");
		writer.newLine();
		writer.write("<h1>" + name + "</h1>");
		writer.newLine();
		writer.write("<table border=\"1\">");
		writer.newLine();
		writer.write("<tr><th>���t</th><th>�v���W�F�N�g</th><th>���e</th>"
				+ "<th>����<br>(����)</th><th>����<br>(����)</th></tr>");
		writer.newLine();
	}

	/**
	 *
	 */
	public void writeFooter(BufferedWriter writer) throws IOException {
		writer.write("</table>");
		writer.newLine();
		writer.write("</body></html>");
		writer.newLine();
	}

	/**
	 *
	 */
	public void setOutputPath(String path) {
		outputPath = path;
	}

	/**
	 *
	 */
	private String id; 

	/**
	 *
	 */
	private String name; 

	/**
	 * dailyJobsTable:Vector <dailyJobs:DailyJobs>
	 */
	private Vector dailyJobsTable = new Vector(); 

	private String outputPath = null;

	private long minimumTime = 0;

	private long maximumTime = 0;

}

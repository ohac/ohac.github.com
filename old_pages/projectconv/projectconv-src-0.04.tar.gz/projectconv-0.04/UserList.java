/**
 * User List
 * Copyright (C) 2001  OHASHI Hideya
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
import java.util.*;
import java.io.*;

/**
 *
 */
public class UserList {

	/**
	 *
	 */
	public void createDocument(Job projects) throws IOException {
		String fname = "users.html";
		if (outputPath != null) fname = outputPath + File.separator + fname;
		FileWriter fileWriter = new FileWriter(fname);
		try {
			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
			writeHeader(bufWriter);
			Iterator ite = users.iterator();
			while (ite.hasNext()) {
				User user = (User)ite.next();
				user.setOutputPath(outputPath);
				user.createDocument(bufWriter, projects);
			}
			writeFooter(bufWriter);
			bufWriter.flush();
		}
		finally {
			fileWriter.close();
		}
	}

	/**
	 *
	 */
	public void addUser(User user) {
		users.addElement(user);
	}

	/**
	 *
	 */
	public void writeHeader(BufferedWriter writer) throws IOException {
		writer.write("<html><body>");
		writer.newLine();
		writer.write("<h1>�\��\</h1>");
		writer.newLine();
		writer.write("<table border=\"1\">");
		writer.newLine();
		writer.write("<tr><th>���O</th></tr>");
		writer.newLine();
	}

	/**
	 *
	 */
	public void writeFooter(BufferedWriter writer) throws IOException {
		writer.write("</table>");
		writer.newLine();
		writer.write("</body></html>");
		writer.newLine();
	}

	/**
	 *
	 */
	public void setOutputPath(String path) {
		outputPath = path;
	}

	/**
	 * users:Vector <user:User>
	 */
	private Vector users = new Vector();

	private String outputPath = null;

}

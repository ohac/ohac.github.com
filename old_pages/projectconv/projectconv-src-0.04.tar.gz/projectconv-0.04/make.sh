#!/bin/bash
rm -fr classes
mkdir classes
javac -encoding SJIS -deprecation -d classes *.java 2>&1
( cd classes ; jar cvmf ../projectconv.mf ../projectconv.jar *.class )

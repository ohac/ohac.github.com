#!/bin/bash
cat >projectconv.spec <<EOD
name: projectconv
Release: 0
Version: $VERSION
Copyright: OHASHI Hideya <ohac@bd.mbn.or.jp>
Group: Utilities
BuildArch: noarch
Source: projectconv-src-$VERSION.tar.gz
Summary: Convert text file to Project HTML Document.
Packager: OHASHI Hideya <ohac@bd.mbn.or.jp>
Distribution: RedHat Linux 7.1
BuildRoot: /home/ohac/rpm/ROOT

%description
Convert text file to Project HTML Document.
Needs Java 2 Runtime Environment.

%prep
rm -rf \$RPM_BUILD_ROOT/*
mkdir -p \$RPM_BUILD_ROOT/usr/bin
mkdir -p \$RPM_BUILD_ROOT/usr/share/man/ja/man1
mkdir -p \$RPM_BUILD_ROOT/usr/share/doc/projectconv
mkdir -p \$RPM_BUILD_ROOT/usr/share/projectconv/jars
mkdir -p \$RPM_BUILD_ROOT/etc/X11/applnk/Utilities
mkdir -p \$RPM_BUILD_ROOT/usr/share/gnome/apps/Utilities

%setup

%build
bash make.sh
htmlconv readme.txt
gzip <projectconv.1 >projectconv.1.gz

%install
install -s projectconv.jar \$RPM_BUILD_ROOT/usr/share/projectconv/jars
install -s projectconv \$RPM_BUILD_ROOT/usr/bin
install -s projectconv.1.gz \$RPM_BUILD_ROOT/usr/share/man/ja/man1
install -s projectconv.desktop \$RPM_BUILD_ROOT/etc/X11/applnk/Utilities
install -s projectconv.desktop \$RPM_BUILD_ROOT/usr/share/gnome/apps/Utilities
install -s readme.txt \$RPM_BUILD_ROOT/usr/share/doc/projectconv
install -s readme.html \$RPM_BUILD_ROOT/usr/share/doc/projectconv
install -s sample.txt \$RPM_BUILD_ROOT/usr/share/doc/projectconv

%clean
rm -rf \$RPM_BUILD_ROOT

%files
%attr(-,root,root) /usr/share/projectconv/jars/projectconv.jar
%attr(-,root,root) /etc/X11/applnk/Utilities/projectconv.desktop
%attr(-,root,root) /usr/share/gnome/apps/Utilities/projectconv.desktop
%attr(-,root,root) /usr/share/man/ja/man1/projectconv.1.gz
%attr(-,root,root) /usr/share/doc/projectconv/readme.txt
%attr(-,root,root) /usr/share/doc/projectconv/readme.html
%attr(-,root,root) /usr/share/doc/projectconv/sample.txt
%attr(-,root,root) /usr/bin/projectconv
EOD
